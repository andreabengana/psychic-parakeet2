@extends('layouts_web.master')

@section('content')


    <h1 style="margin-top: 5%; margin-bottom: 5%;"><center>iREQUEST</center></h1>

<!--CAROUSEL-->
       <div class="container">
          <br>
          <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
              <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
              <li data-target="#myCarousel" data-slide-to="1"></li>
              <li data-target="#myCarousel" data-slide-to="2"></li>
              <li data-target="#myCarousel" data-slide-to="3"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
              <div class="item active">
                <img src="http://placehold.it/900x500/39CCCC/ffffff&text=I+Love+Bootstrap" alt="Chania" width="460" height="345">
              </div>

              <div class="item">
                <img src="http://placehold.it/900x500/3c8dbc/ffffff&text=I+Love+Bootstrap" alt="Chania" width="460" height="345">
              </div>
            
              <div class="item">
                <img src="http://placehold.it/900x500/f39c12/ffffff&text=I+Love+Bootstrap" alt="Flower" width="460" height="345">
              </div>

            </div>

            <!-- Left and right controls -->
            <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
              <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
              <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
        </div><br><br>

<!--CAROUSEL-->
    <div class="col-md-1">
    </div>
    <div class="row">
        <h3 style="background-color: #d9d9d9; font-family: Montserrat"><b>Step 1:</b> Select your Request</h3>
    </div><br>

    <div class="col-sm-3 col-md-6"
         style="border: 3px solid black;
               background-color: #fff;
               font-family: Montserrat;
               font-size: 25px;
               height: 250px;
               width: 250px;
               margin-bottom: 40px;
               margin-left: 20%;">

    <center><img src="{{ asset('assets/images/dr.png')}}" style="width: 150px; height: 150px;" alt=""></center>
    <center><a href="<?php echo 'docreq' ?>"> REGULAR DOCUMENTS </a></center>
    </div>

    <div class="col-sm-9 col-md-6" 
         style="border: 3px solid black;
                background-color: #fff;
                font-family: Montserrat;
                font-size: 25px;
                height: 250px;
                width: 250px;
                margin-left: 30px;
                margin-bottom: 40px;">

     <center><img src="{{ asset('assets/images/bd.png')}}" style="width: 150px; height: 150px;" alt=""></center>
     <center><a href="<?php echo 'busdocs' ?>"> BUSINESS DOCUMENTS </a></center>
    </div>

 
    <div class="col-sm-3 col-md-6" 
         style="border: 3px solid black;
                background-color: #fff;
                font-family: Montserrat;
                font-size: 25px;
                height: 250px;
                width: 250px;
                margin-left: 40px;
                margin-bottom: 40px;
                align:center">

    <center><img src="{{ asset('assets/images/items.png')}}" style="width: 150px; height: 150px;" alt=""></center>
    <center><a href="<?php echo 'items' ?>">  ITEMS &amp; FACILITIES</a></center>
    </div>

    <div class="col-sm-9 col-md-6" >
    </div>


@stop
