				<!---->
					<div class="header-logo" style="background-color:#3CB371">
						
						<div class="top-nav" style="background-color:">
							<span class="icon"><img src="{{ asset('assets/images/menu.png')}}" alt=""> </span>
							<ul style="background-color:#737373">
								<li ><a href="<?php echo 'index' ?>">HOME</a> </li>
								<li ><a href="<?php echo 'about' ?>" >ABOUT  </a> </li>
								<li><a href="<?php echo 'request' ?>"  >iRequest</a></li>
								<li><a href="<?php echo 'news' ?>" >NEWS </a></li>
								<li><a href="<?php echo 'contact' ?>" >CONTACT US</a></li>
								<li><a href="<?php echo 'login' ?>" >LOGIN</a></li>
							</ul>
							<!--script-->
						<script>
							$("span.icon").click(function(){
								$(".top-nav ul").slideToggle(500, function(){
								});
							});
					</script>				
				</div>
				<div class="clearfix"> </div>
					</div>
			<!---->
			<div class="top-menu">					
					<ul>
						<li><a href="<?php echo 'index' ?>">HOME</a> </li>
						<li><a href="<?php echo 'about' ?>">ABOUT  </a> </li>
						<li><a href="<?php echo 'request' ?>">iRequest</a></li>
						<li><a href="<?php echo 'index' ?>"> <img src="{{ asset('assets/images/lo1.png')}}" alt=""> </a></li>
						<li><a href="<?php echo 'news' ?>">NEWS </a></li>
						<li><a href="<?php echo 'contact' ?>">CONTACT US</a></li>
						<li><a href="<?php echo 'login' ?>">LOGIN</a></li>
					</ul>
				</div>
					<!--script-->