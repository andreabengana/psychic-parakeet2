<?php

class MainFacilityController extends BaseController {

	public function showRecords()
	{

		$facilities = DB::table('tblfacility')
			->get();

		return View::make('mainFacility.facility')
			->with('faci', $facilities);
	}

	public function addFacility()
	{


				if(Input::hasFile('txtImage'))
				{
					$newName = time().Input::file('txtImage')->getClientOriginalName();

					Input::file('txtImage')->move(public_path().'/bower_components/admin-lte/dist/images/', $newName);


					DB::table('tblfacility')
						->insert(array(
								'FacilityName' => Input::get('txtFacility'),
								'Description' => Input::get('txtDesciption'),
								'Location' => Input::get('txtLocation'),
								'Capacity' => Input::get('txtCapacity'),
								'ResRental' => Input::get('txtResFee'),
								'NResRental' => Input::get('txtNonResFee'),
								'FacilityImage' => $newName
							));
				}

				else
				{
					DB::table('tblfacility')
						->insert(array(
								'FacilityName' => Input::get('txtFacility'),
								'Description' => Input::get('txtDesciption'),
								'Location' => Input::get('txtLocation'),
								'Capacity' => Input::get('txtCapacity'),
								'ResRental' => Input::get('txtResFee'),
								'NResRental' => Input::get('txtNonResFee')
							));
				}




		$facilities = DB::table('tblfacility')
			->get();

		return Response::json(array('faci' => $facilities));
				
				
	}
	

}
