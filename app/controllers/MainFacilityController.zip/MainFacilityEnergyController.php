<?php

class MainFacilityEnergyController extends BaseController {

	public function showRecords()
	{
		$facility = DB::table('tblfacility')
			->get();

		return View::make('mainFacility.facility_energy')
			->with('facility', $facility);
	}

	public function getFacilityInfo()
	{
		$faciInfo = DB::table('tblfacility')
			->where('FacilityID', '=', Input::get('facilityID'))
			->get();

		$faciDev = DB::table('tblfacilityenergy')
			->where('DeviceFacility', '=', Input::get('facilityID'))
			->get();

		return Response::json(array('faciInfo' => $faciInfo, 'faciDev' => $faciDev));
				
	}

	public function addDevice()
	{
		DB::table('tblfacilityenergy')
			->insert(array(
					'DeviceName' => Input::get('deviceName'),
					'DeviceDesc' => Input::get('devDesc'),
					'DevicePrice' => Input::get('devPrice'),
					'DeviceQuantity' => Input::get('devQuantity'),
					'DeviceAmount' => Input::get('devPrice') * Input::get('devQuantity'),
					'DeviceFacility' => Input::get('devFaci')
				));

		$dev = DB::table('tblfacilityenergy')
			->where('DeviceFacility', '=', Input::get('devFaci'))
			->get();

		return Response::json(array('devices' => $dev));
	}
	

}
