<?php

class TransDocumentRequestController extends BaseController {

	public function showRecords()
	{

		if(Input::get('sort') != "")
		{

			$req = DB::table('tbldocumentrequest')
				->join('tblresident', 'tblresident.ResidentID', '=', 'tbldocumentrequest.RFResidentID')
				->join('tbldocumentrequest2', 'tbldocumentrequest2.RequestID', '=', 'tbldocumentrequest.RequestID')
				->where('tbldocumentrequest2.DocReqStatus', '=', Input::get('sort'))
				->get();

			$reqdoc = DB::table('tbldocumentrequest')
				->join('tbldocumentrequest2', 'tbldocumentrequest2.RequestID', '=', 'tbldocumentrequest.RequestID')
				->join('tbldocumentdetails', 'tbldocumentdetails.DocumentID', '=', 'tbldocumentrequest2.DocumentID')
				->where('tbldocumentrequest2.DocReqStatus', '=', Input::get('sort'))
				->get();


		
			return View::make('transDocument.doc_request')
				->with('info', $req)
				->with('docInfo', $reqdoc);
		}

		else
		{
			$req = DB::table('tbldocumentrequest')
				->join('tblresident', 'tblresident.ResidentID', '=', 'tbldocumentrequest.RFResidentID')
				->get();

			$reqdoc = DB::table('tbldocumentrequest')
				->join('tbldocumentrequest2', 'tbldocumentrequest2.RequestID', '=', 'tbldocumentrequest.RequestID')
				->join('tbldocumentdetails', 'tbldocumentdetails.DocumentID', '=', 'tbldocumentrequest2.DocumentID')
				->get();

			$checkReqID = DB::table('tbldocumentrequest')
				->where('EmailSent', '=', 'No')
				->get();

			$checkReqIDcount = DB::table('tbldocumentrequest')
				->where('EmailSent', '=', 'No')
				->count();



			$checkReqID2 = DB::table('tbldocumentrequest2')
				->get();

			$checkReqID2count = DB::table('tbldocumentrequest2')
				->count();

			for($i = 0; $i < $checkReqIDcount; $i++)
			{
				$ctr = 0;
				for($j = 0; $j < $checkReqID2count; $j++)
				{
					if($checkReqID[$i]->RequestID == $checkReqID2[$j]->RequestID)
					{
						$ctr++;
					}
				}

				$ctr2 = 0;
				for($j = 0; $j < $checkReqID2count; $j++)
				{
					if($checkReqID[$i]->RequestID == $checkReqID2[$j]->RequestID && $checkReqID2[$j]->DocReqStatus == "Done/Unclaimed")
					{
						$ctr2++;
					}
				}

				if($ctr == $ctr2)
				{
					// $done = DB::table('tbldocumentrequest')
					// 	->join('tbldocumentrequest2', 'tbldocumentrequest.RequestID', '=', 'tbldocumentrequest.RequestID')
					// 	->join('tbldocumentdetails', 'tbldocumentdetails.DocumentID', '=', 'tbldocumentrequest2.DocumentID')
					// 	->where('tbldocumentrequest.EmailSent', '=', 'No')
					// 	->where('tbldocumentrequest.RequestID', '=', $checkReqID[$i]->RequestID)
					// 	->where('tbldocumentrequest2.RequestID', '=', $checkReqID[$i]->RequestID)
					// 	->where('tbldocumentrequest2.DocReqStatus', '=', 'Done/Unclaimed')
					// 	->get();

					

					// Mail::send('emailPDF.doneDocRequest', array('data' => $done), function($message) use ($done, $i)
					// {
					//     $message->to($done[$i]->Email)->subject('Document Update');
					// });

					DB::table('tbldocumentrequest')
						->where('RequestID', '=', $checkReqID[$i]->RequestID)
						->update(array(
								'EmailSent' => "Yes"
							));

				}


			}


		
			return View::make('transDocument.doc_request')
				->with('info', $req)
				->with('docInfo', $reqdoc);
		}
	}

	public function documentRequestForm()
	{

		$rname = DB::table('tblresident')
			->get();

		$docs = DB::table('tbldocumentdetails')
				->where('DocClass', '=', "Regular Document")
				->get();

		$reqID = DB::table('tbldocumentrequest')
			->orderBy('RequestID', 'desc')
			->take(1)
			->get();

		return View::make('transDocument.docRequest_form')
			->with('rname', $rname)
			->with('docs', $docs)
			->with('reqID', $reqID);
	}

	public function getDocRequestedForInfo()
	{
		if(Request::ajax())
		{
			$info = DB::table('tblresident')
				->join('tblfamily', 'tblfamily.FamilyID', '=', 'tblresident.FamilyID')
				->join('tblhouse', 'tblhouse.HouseID', '=', 'tblfamily.HouseID')
				->where('ResidentID', '=', Input::get('resID'))
				->get();

			

			return Response::json(array('info' => $info));
		}
	}

	
	public function addDocumentRequest()
	{$string = bin2hex(openssl_random_pseudo_bytes(3));


		DB::table('tbldocumentrequest')
			->insert(array(
					'RequestID' => Input::get('txtRequestID'),
					'Requestor' => Input::get('txtRequestor'),
					'RFResidentID' => Input::get('txtRequestedFor'),
					'DateOfRequest' => date('Y/m/d'),
					'Email' => Input::get('txtEmail'),
					'SecretCode' => $string
				));

		$docCount = DB::table('tbldocumentdetails')
			->where('DocStatus', '=', 'active')
			->count();

		$docD = DB::table('tbldocumentdetails')
				->where('DocStatus', '=', 'active')
				->get();

		$i;
		for($i=0; $i<$docCount;$i++)
		{
			if(Input::get('checkDoc_'.$docD[$i]->DocumentID))
			{
				DB::table('tbldocumentrequest2')
					->insert(array(
							'RequestID' => Input::get('txtRequestID'),
							'DocumentID' => $docD[$i]->DocumentID,
							'DocReqPurpose' => Input::get('purpose_'.$docD[$i]->DocumentID),
							'DocReqStatus' => 'New'
						));
			}
		}


		return Redirect::to('documentRequest');
	}

	public function docSummary()
	{
		$summary = DB::table('tbldocumentrequest')
			->join('tbldocumentrequest2', 'tbldocumentrequest2.RequestID', '=', 'tbldocumentrequest.RequestID')
			->join('tblresident', 'tblresident.ResidentID', '=', 'tbldocumentrequest.RFResidentID')
			->join('tbldocumentdetails', 'tbldocumentrequest2.DocumentID', '=', 'tbldocumentdetails.DocumentID')
			->where('tbldocumentrequest.RequestID','=', Input::get('ReqID'))
			->get();

		$pdf = PDF::loadView('emailPDF.docSummary', array('summary' =>$summary));
        return $pdf->download("Summary.pdf");
	}

	public function sendDocStat()
	{
		$summary = DB::table('tbldocumentrequest')
			->join('tbldocumentrequest2', 'tbldocumentrequest2.RequestID', '=', 'tbldocumentrequest.RequestID')
			->join('tblresident', 'tblresident.ResidentID', '=', 'tbldocumentrequest.RFResidentID')
			->join('tbldocumentdetails', 'tbldocumentrequest2.DocumentID', '=', 'tbldocumentdetails.DocumentID')
			->where('tbldocumentrequest.RequestID','=', Input::get('ReqID'))
			->get();


		Mail::send('emailPDF.doneDocRequest', array('summary' => $summary), function($message) use ($summary)
			{
			    $message->to($summary[0]->Email)->subject('Docu Update');
			});

		return Redirect::to('documentRequest');


	}

	

	public function createDocumentRequest()
	{
		$template = DB::table('tbldocumentdetails')
			->where('DocumentID', '=', Input::get('varname'))
			->get();

		$information = DB::table('tbldocumentrequest')
			->join('tblresident', 'tblresident.ResidentID', '=', 'tbldocumentrequest.RFResidentID')
			->join('tblfamily', 'tblfamily.FamilyID', '=', 'tblresident.FamilyID')
			->join('tblhouse', 'tblhouse.HouseID', '=', 'tblfamily.HouseID')
			->join('tbldocumentrequest2', 'tbldocumentrequest2.RequestID', '=', 'tbldocumentrequest.RequestID')
			->where('tbldocumentrequest.RequestID', '=', Input::get('ReqID'))
			->get();

		$forSignature = DB::table('tblofficialaccount')
			->where('Username', '=', Session::get('username'))
			->get();

		return View::make('transDocument.doc_make')
			->with('template', $template)
			->with('reqInfo', $information)
			->with('fs', $forSignature)
			->with('IDR', Input::get('ReqID'))
			->with('IDD', Input::get('varname'));
	}

	public function saveTemplate()
	{
		if(Input::get('stat')!="Done/Unclaimed")
		{


			if(Input::get('position') == "Kagawad")
			{
				DB::table('tbldocumentrequest2')
					->where('RequestID', '=', Input::get('idr'))
					->where('DocumentID', '=', Input::get('idd'))
					->update(array(
							'TemplateFinal' => Input::get('doc'),
							'DocReqStatus' => "Pending"
						));
			}
			else if(Input::get('position') == "Secretary")
			{
				DB::table('tbldocumentrequest2')
					->where('RequestID', '=', Input::get('idr'))
					->where('DocumentID', '=', Input::get('idd'))
					->update(array(
							'TemplateFinal' => Input::get('doc'),
							'DocReqStatus' => "Approved"
						));
			}
			else if(Input::get('position') == "Chairman")
			{
				DB::table('tbldocumentrequest2')
					->where('RequestID', '=', Input::get('idr'))
					->where('DocumentID', '=', Input::get('idd'))
					->update(array(
							'TemplateFinal' => Input::get('doc'),
							'DocReqStatus' => "Done/Unclaimed"
						));
			}

		}
		else if(Input::get('stat')=="Done/Unclaimed")
		{
			DB::table('tbldocumentrequest2')
				->where('RequestID', '=', Input::get('idr'))
				->where('DocumentID', '=', Input::get('idd'))
				->update(array(
						'DocReqStatus' => "Released"
					));

			DB::table('tbldocumentrequest')
				->where('RequestID', '=', Input::get('idr'))
				->update(array(
						'DateOfReleased' => date('Y/m/d')
					));


		}

		//return View('documentRequest');
	}

	public function getFinalTemplate()
	{
		if(Request::ajax()){
			$ft = DB::table('tbldocumentrequest2')
				->where('RequestID', '=', Input::get('idr'))
				->where('DocumentID', '=', Input::get('idd'))
				->get();


			return Response::json(array('ft' => $ft));
		}
		
	}

	public function printTemplate()
	{
		//if(Request::ajax())
		//{
			

			$finalTemplate = DB::table('tbldocumentrequest2')
				->where('RequestID', '=', Input::get('idr'))
				->where('DocumentID', '=', Input::get('idd'))
				->get();

			$orient = DB::table('tbldocumentdetails')
				->where('DocumentID', '=', Input::get('idd'))
				->get();

//			var_dump($finalTemplate[0]->TemplateFinal);
			$pdf = PDF::loadHTML('<html style = "margin: 0px;"><div style = "position:relative">'.$finalTemplate[0]->TemplateFinal.'</div></div></html>')->setPaper('a4', 'Landscape');


			// $pdf = PDF::loadHTML('<html style = "margin: 0px; 0px; 0px; 0px;"><div style = "position:relative">
                
   //                <div id="forBG" style="position: inherit; left: 0px; top: 0px; right: 0px; height: 772px; width: 1120px; border: 1px solid black">

   //                <img src = "" width="100%" height = "100%">
                  	
                    
   //                  <div id="forTextArea" style="text-align: left; position: absolute; left: 340px; top: 160px; right: 20px; bottom: 70px;"><blockquote style="margin: 0px 0px 0px 40px; border: none; padding: 0px;"><blockquote style="margin: 0px 0px 0px 40px; border: none; padding: 0px;"><blockquote style="margin: 0px 0px 0px 40px; border: none; padding: 0px;"><blockquote style="margin: 0px 0px 0px 40px; border: none; padding: 0px;"><blockquote style="margin: 0px 0px 0px 40px; border: none; padding: 0px;"><h1>Barangay Certificate</h1></blockquote></blockquote></blockquote></blockquote></blockquote><br><h1><b></b></h1><div>To whom it may concern:<br><br>This certify that <u>______________________</u>, of legal age, is a bonafide resident of this barangay with postal address at <u>______________________</u> Old Sta. Mesa, Manila.<br><br>He/She presently do not have any pending case of any kind in our barangay records.<br><br>This certification is being used upon the request of<u>______________________</u>for <u>______________________</u> purpose only.<br><br>Issued <u>______________________</u>  day of<u>______________________</u>, year<u>______________________</u> at Barangay 599, Zone 59, District VI City of Manila.<br><br><br>Certified by:<br><br><br><br><br>Barangay Captain<br></div><div id="Kagawadsign" class="ui-draggable ui-draggable-handle" style="position: relative; width: 757px; right: auto; height: 56px; bottom: auto; left: -9px; top: -52px;"><img src="http://localhost/BREMS%20072316/public/bower_components/admin-lte/dist/images/pau.png" width="20%"></div><div id="Secretarysign" class="ui-draggable ui-draggable-handle" style="position: relative; width: 757px; right: auto; height: 98px; bottom: auto; left: 153px; top: -137px;"><img src="http://localhost/BREMS%20072316/public/bower_components/admin-lte/dist/images/5.png" width="20%"></div><div id="Chairmansign" class="ui-draggable ui-draggable-handle" style="position: relative; width: 757px; right: auto; height: 60px; bottom: auto; left: 236px; top: -378px;"><img src="http://localhost/BREMS%20072316/public/bower_components/admin-lte/dist/images/4.png" width="20%"></div></div>
   //                </div>


                
   //              </div></div></html>')->setPaper('a4', 'Landscape');
			

        	return $pdf->download("hey.pdf");
		//}
		
	}

}