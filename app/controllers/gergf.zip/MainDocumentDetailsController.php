<?php

class MainDocumentDetailsController extends BaseController {

	public function showRecords()
	{
		$documentDetails = DB::table('tbldocumentdetails')
			->get();

		$temp = DB::table('tbltemplate')
			->get();

		return View::make('mainDocument.doc_detail')
			->with('dDetails', $documentDetails)
			->with('template', $temp);
	}

	public function classification()
	{
		$doc = DB::table('tbldocumentdetails')
			->get();

		return Response::json(array('drop' => $doc));
	}

	public function addRecord()
	{

		if(Request::ajax())
		{

			//$newName = time().Input::file('fileTemplate')->getClientOriginalName();

			//Input::file('fileTemplate')->move(public_path().'/bower_components/admin-lte/dist/images/', $newName);


			$class;
			if(Input::get('txtClass') == "1")
			{
				$class = "Regular Document";
			}
			else
			{
				$class = "Business Document";
			}


			DB::table('tbldocumentdetails')
				->insert(array(
						'DocumentName' => Input::get('txtDocName'),
						'DocumentFee' => Input::get('txtFee'),
						'DocumentTemplate' => Input::get('txtTemplate'),
						'DocTemplate' => Input::get('txtDocTemplate'),
						'DocClass' => $class
					));

			$documentDetails = DB::table('tbldocumentdetails')
				->get();

			return Response::json(array('oDetails' => $documentDetails));
		}

	}

	public function updateRecord()
	{

		if(Request::ajax())
		{
			//if(Input::file('etxt4'))
			//{
				//$newName = time().Input::file('etxt4')->getClientOriginalName();

				//Input::file('etxt4')->move(public_path().'/bower_components/admin-lte/dist/images/', $newName);

				DB::table('tbldocumentdetails')
					->where('DocumentID', '=', Input::get('etxt1'))
					->update(array(
							'DocumentName' => Input::get('etxt2'),
							'DocumentFee' => Input::get('etxt3'),
							'DocTemplate' => Input::get('eTemplate')
						));

				
			/*}
			else
			{
				DB::table('tbldocumentdetails')
					->where('DocumentID', '=', Input::get('etxt1'))
					->update(array(
							'DocumentName' => Input::get('etxt2'),
							'DocumentFee' => Input::get('etxt3')
						));
			}
			*/
			$documentDetails = DB::table('tbldocumentdetails')
				->get();

			return Response::json(array('oDetails' => $documentDetails));
			
		}
	}


	public function deleteRecord()
	{

		if(Request::ajax())
		{
			
				DB::table('tbldocumentdetails')
					->where('DocumentID', '=', Input::get('dtxt1'))
					->delete();
			
			$documentDetails = DB::table('tbldocumentdetails')
				->get();

			return Response::json(array('oDetails' => $documentDetails));
			
		}
	}

	public function getInfo()
	{
		if(Request::ajax())
		{
			$dDetails = DB::table('tbldocumentdetails')
				->where('DocumentID', '=', Input::get('id'))
				->get();

			
			return Response::json(array('dDetails' => $dDetails));
		}
	}

	public function getBG()
	{
		if(Request::ajax())
		{
			$BG = DB::table('tbltemplate')
				->where('TemplateID', '=', Input::get('id'))
				->get();

			return Response::json(array('BG' => $BG));
		}
	}

	public function template()
	{
		$temp = DB::table('tbldocumentdetails')
			->where('DocumentID', '=', Input::get('varname'))
			->get();

		return View::make('mainDocument.doc_template')
			->with('temp', $temp);
	}



	public function getContent()
	{
		if(Request::ajax())
		{
			$sample = DB::table('tbldocumentdetails')
				->where('DocumentID', '=', Input::get('varname'))
				->get();


			return Response::json(array('sample' => $sample));
		}
		
	}

	public function addTemplate()
	{
		DB::table('tbldocumentdetails')
			->where('DocumentID', '=', '1')
			->update(array(
					'DocTemplate' => Input::get('Template')
				));

		var_dump(Input::get('Template'));
	}

}
