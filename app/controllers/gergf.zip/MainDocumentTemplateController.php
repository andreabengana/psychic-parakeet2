<?php

class MainDocumentTemplateController extends BaseController {

	public function showRecords()
	{
		$template = DB::table('tbltemplate')
			->where('status', '=', 'active')
			->get();

		return View::make('mainDocument.doc_template')
			->with('temp', $template);
	}

	public function getInfo()
	{
		if(Request::ajax())
		{
			$template = DB::table('tbltemplate')
				->where('TemplateID', '=', Input::get('id'))
				->get();

			return Response::json(array('temp' => $template));
		}
	}

public function addRecord()
	{
		if(Request::ajax())
		{
			
				$newName = time().Input::file('txtTemplate')->getClientOriginalName();

				Input::file('txtTemplate')->move(public_path().'/bower_components/admin-lte/dist/images/', $newName);

				DB::table('tbltemplate')
					->insert(array(
							'TemplateName' => Input::get('txtTemplateName'),
							'Template' => $newName,
							'TemplateOrientation' => Input::get('txtTemplateOrientation'),
							'status' => 'active'

						));

			$template = DB::table('tbltemplate')
				->where('status', '=', 'active')
				->get();

			return Response::json(array('temp' => $template));
		}
	}

	public function updateRecord()
	{
		if(Request::ajax())
		{
			if(Input::hasFile('etxtImageChange'))
			{
				$newName = time().Input::file('etxtImageChange')->getClientOriginalName();

				Input::file('etxtImageChange')->move(public_path().'/bower_components/admin-lte/dist/images/', $newName);

				DB::table('tbltemplate')
					->where('TemplateID', '=', Input::get('etxtID'))
					->update(array(
							'TemplateName' => Input::get('etxtTemplateName'),
							'Template' => $newName

						));
			}
			else
			{

				DB::table('tbltemplate')
					->where('TemplateID', '=', Input::get('etxtID'))
					->update(array(
							'TemplateName' => Input::get('etxtTemplateName')
							
						));
			}

			
			
	
			$template = DB::table('tbltemplate')
				->where('status', '=', 'active')
				->get();

			return Response::json(array('temp' => $template));
		}
	}

	public function deleteRecord()
	{

		if(Request::ajax())
		{
			DB::table('tbltemplate')
				->where('TemplateID', '=', Input::get('dtxtID'))
				->update(array(
						'status' => 'inactive'

					));

			$template = DB::table('tbltemplate')
				->where('status', '=', 'active')
				->get();

			return Response::json(array('temp' => $template));
		}
	}

}
